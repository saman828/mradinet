<?php

define("ROOT", dirname(__FILE__) . DIRECTORY_SEPARATOR, true);

if (session_status() == PHP_SESSION_NONE)
    session_start();

include_once(ROOT . "App/AutoLoader.php");

$App = new Application();
$App->SetSession('Captcha', '45342');