<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

class Telegram
{
    const CALLBACK_QUERY = 'callback_query';
    const EDITED_MESSAGE = 'edited_message';
    const REPLY = 'reply';
    const MESSAGE = 'message';
    const PHOTO = 'photo';
    const VIDEO = 'video';
    const AUDIO = 'audio';
    const VOICE = 'voice';
    const DOCUMENT = 'document';
    const LOCATION = 'location';
    const CONTACT = 'contact';
    const CHANNEL_POST = 'channel_post';

    private $Token = '';
    private $Data = [];

    public function __construct($token)
    {
        $this->Token = $token;
        @$this->Data = json_decode(file_get_contents('php://input'));
    }

    private function Request($api, array $parameters = [], $post = true)
    {
        $url = 'https://api.telegram.org/bot' . $this->Token . '/' . $api;

        if (isset($parameters['chat_id']))
        {
            $url = $url . '?chat_id=' . $parameters['chat_id'];
            unset($parameters['chat_id']);
        }

        $curl = curl_init();
        $options = [CURLOPT_URL => $url, CURLOPT_HEADER => 0, CURLOPT_RETURNTRANSFER => 1, CURLOPT_SSL_VERIFYPEER => 0];

        if ($post)
        {
            $options[CURLOPT_POST] = 1;
            $options[CURLOPT_POSTFIELDS] = $parameters;
        }

        curl_setopt_array($curl, $options);
        $result = curl_exec($curl);

        if ($result === false)
            $result = json_encode(['ok' => false, 'curl_error_code' => curl_errno($curl), 'curl_error' => curl_error($curl)]);

        curl_close($curl);

        return json_decode($result);
    }

    public function GetMe()
    {
        return $this->Request('getMe', [], false);
    }

    public function RespondSuccess()
    {
        http_response_code(200);

        return json_encode(['status' => 'success']);
    }

    public function SendMessage($chatId, $text, array $parameters = [])
    {
        return $this->Request('sendMessage', array_merge(['chat_id' => $chatId, 'text' => $text], $parameters));
    }

    public function ForwardMessage($chatId, $fromChatId, $messageId, array $parameters = [])
    {
        return $this->Request('forwardMessage', array_merge(['chat_id' => $chatId, 'from_chat_id' => $fromChatId, 'message_id' => $messageId], $parameters));
    }

    public function SendPhoto($chatId, $photo, array $parameters = [])
    {
        return $this->Request('sendPhoto', array_merge(['chat_id' => $chatId, 'photo' => $photo], $parameters));
    }

    public function SendAudio($chatId, $audio, array $parameters = [])
    {
        return $this->Request('sendAudio', array_merge(['chat_id' => $chatId, 'audio' => $audio], $parameters));
    }

    public function SendDocument($chatId, $document, array $parameters = [])
    {
        return $this->Request('sendDocument', array_merge(['chat_id' => $chatId, 'document' => $document], $parameters));
    }

    public function SendSticker($chatId, $sticker, array $parameters = [])
    {
        return $this->Request('sendSticker', array_merge(['chat_id' => $chatId, 'sticker' => $sticker], $parameters));
    }

    public function SendVideo($chatId, $video, array $parameters = [])
    {
        return $this->Request('sendVideo', array_merge(['chat_id' => $chatId, 'video' => $video], $parameters));
    }

    public function SendVoice($chatId, $voice, array $parameters = [])
    {
        return $this->Request('sendVoice', array_merge(['chat_id' => $chatId, 'voice' => $voice], $parameters));
    }

    public function SendLocation($chatId, $latitude, $longitude, array $parameters = [])
    {
        return $this->Request('sendLocation', array_merge(['chat_id' => $chatId, 'latitude' => $latitude, 'longitude' => $longitude], $parameters));
    }

    public function SendVenue($chatId, $latitude, $longitude, array $parameters = [])
    {
        return $this->Request('sendVenue', array_merge(['chat_id' => $chatId, 'latitude' => $latitude, 'longitude' => $longitude], $parameters));
    }

    public function SendContact($chatId, $phoneNumber, $firstName, array $parameters = [])
    {
        return $this->Request('sendContact', array_merge(['chat_id' => $chatId, 'phone_number' => $phoneNumber, 'first_name' => $firstName], $parameters));
    }

    public function SendChatAction($chatId, $action)
    {
        return $this->Request('sendChatAction', ['chat_id' => $chatId, 'action' => $action]);
    }

    public function GetUserProfilePhotos($userId, array $parameters = [])
    {
        return $this->Request('getUserProfilePhotos', array_merge(['user_id' => $userId], $parameters));
    }

    public function GetFile($fileId)
    {
        return $this->Request('getFile', ['file_id' => $fileId]);
    }

    public function KickChatMember($chatId, $userId, array $parameters = [])
    {
        return $this->Request('kickChatMember', array_merge(['chat_id' => $chatId, 'user_id' => $userId], $parameters));
    }

    public function LeaveChat($chatId)
    {
        return $this->Request('leaveChat', ['chat_id' => $chatId]);
    }

    public function UnBanChatMember($chatId, $userId)
    {
        return $this->Request('unbanChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
    }

    public function GetChat($chatId)
    {
        return $this->Request('getChat', ['chat_id' => $chatId]);
    }

    public function GetChatAdministrators($chatId)
    {
        return $this->Request('getChatAdministrators', ['chat_id' => $chatId]);
    }

    public function GetChatMembersCount($chatId)
    {
        return $this->Request('getChatMembersCount', ['chat_id' => $chatId]);
    }

    public function GetChatMember($chatId, $userId)
    {
        return $this->Request('getChatMember', ['chat_id' => $chatId, 'user_id' => $userId]);
    }

    public function AnswerInlineQuery($inlineQueryId, $results, array $parameters = [])
    {
        return $this->Request('answerInlineQuery', array_merge(['inline_query_id' => $inlineQueryId, 'results' => $results], $parameters));
    }

    public function SetGameScore($userId, $score, array $parameters = [])
    {
        return $this->Request('setGameScore', array_merge(['user_id' => $userId, 'score' => $score], $parameters));
    }

    public function AnswerCallbackQuery($callbackQueryId, array $parameters = [])
    {
        return $this->Request('answerCallbackQuery', array_merge(['callback_query_id' => $callbackQueryId], $parameters));
    }

    public function EditMessageText($text, array $parameters = [])
    {
        return $this->Request('editMessageText', array_merge(['text' => $text], $parameters));
    }

    public function EditMessageCaption(array $parameters = [])
    {
        return $this->Request('editMessageCaption', $parameters);
    }

    public function EditMessageReplyMarkup(array $parameters = [])
    {
        return $this->Request('editMessageReplyMarkup', $parameters);
    }

    public function DownloadFile($telegramFilePath, $localFilePath)
    {
        $file_url = 'https://api.telegram.org/file/bot' . $this->Token . '/' . $telegramFilePath;
        $in = fopen($file_url, 'rb');
        $out = fopen($localFilePath, 'wb');

        while ($chunk = fread($in, 8192))
        {
            fwrite($out, $chunk, 8192);
        }

        fclose($in);
        fclose($out);
    }

    public function SetWebHook($url, $certificate = '')
    {
        $requestBody = ['url' => $url];

        if (!empty($certificate))
            $requestBody['certificate'] = "@$certificate";

        return $this->Request('setWebhook', $requestBody);
    }

    public function DeleteWebHook()
    {
        return $this->Request('deleteWebhook', [], false);
    }

    public function SendInvoice($chatId, $title, $description, $payload, $providerToken, $startParameter, $currency, $prices, array $parameters = [])
    {
        return $this->Request('sendInvoice', array_merge(['chat_id' => $chatId, 'title' => $title, 'description' => $description, 'payload' => $payload, 'provider_token' => $providerToken, 'start_parameter' => $startParameter, 'currency' => $currency, 'prices' => $prices], $parameters));
    }

    public function AnswerShippingQuery($shippingQueryId, $ok, array $parameters = [])
    {
        return $this->Request('answerShippingQuery', array_merge(['shipping_query_id' => $shippingQueryId, 'ok' => $ok], $parameters));
    }

    public function AnswerPreCheckoutQuery($answerPreCheckoutQuery, $ok, array $parameters = [])
    {
        return $this->Request('answerPreCheckoutQuery', array_merge(['answerPreCheckoutQuery' => $answerPreCheckoutQuery, 'ok' => $ok], $parameters));
    }

    public function SendVideoNote($chatId, $video_note, array $parameters = [])
    {
        return $this->Request('sendVideoNote', array_merge(['chat_id' => $chatId, 'video_note' => $video_note], $parameters));
    }

    public function RestrictChatMember($chatId, $userId, array $parameters = [])
    {
        return $this->Request('restrictChatMember', array_merge(['chat_id' => $chatId, 'user_id' => $userId], $parameters));
    }

    public function PromoteChatMember($chatId, $userId, array $parameters = [])
    {
        return $this->Request('promoteChatMember', array_merge(['chat_id' => $chatId, 'user_id' => $userId], $parameters));
    }

    public function ExportChatInviteLink($chatId)
    {
        return $this->Request('exportChatInviteLink', ['chat_id' => $chatId]);
    }

    public function SetChatPhoto($chatId, $photo)
    {
        return $this->Request('setChatPhoto', ['chat_id' => $chatId, 'photo' => $photo]);
    }

    public function DeleteChatPhoto($chatId)
    {
        return $this->Request('deleteChatPhoto', ['chat_id' => $chatId]);
    }

    public function SetChatTitle($chatId, $title)
    {
        return $this->Request('setChatTitle', ['chat_id' => $chatId, 'title' => $title]);
    }

    public function SetChatDescription($chatId, array $parameters = [])
    {
        return $this->Request('setChatDescription', array_merge(['chat_id' => $chatId], $parameters));
    }

    public function PinChatMessage($chatId, $messageId, array $parameters = [])
    {
        return $this->Request('pinChatMessage', array_merge(['chat_id' => $chatId, 'message_id' => $messageId], $parameters));
    }

    public function UnPinChatMessage($chatId)
    {
        return $this->Request('unpinChatMessage', ['chat_id' => $chatId]);
    }

    public function GetStickerSet($name)
    {
        return $this->Request('getStickerSet', ['name' => $name]);
    }

    public function UploadStickerFile($userId, $sticker)
    {
        return $this->Request('uploadStickerFile', ['user_id' => $userId, 'png_sticker' => $sticker]);
    }

    public function CreateNewStickerSet($userId, $name, $title, $sticker, $emojis, array $parameters = [])
    {
        return $this->Request('createNewStickerSet', array_merge(['user_id' => $userId, 'name' => $name, 'title' => $title, 'png_sticker' => $sticker, 'emojis' => $emojis], $parameters));
    }

    public function AddStickerToSet($userId, $name, $title, $sticker, $emojis, array $parameters = [])
    {
        return $this->Request('addStickerToSet', array_merge(['user_id' => $userId, 'name' => $name, 'title' => $title, 'png_sticker' => $sticker, 'emojis' => $emojis], $parameters));
    }

    public function SetStickerPositionInSet($sticker, $position)
    {
        return $this->Request('setStickerPositionInSet', ['sticker' => $sticker, 'position' => $position]);
    }

    public function DeleteStickerFromSet($sticker)
    {
        return $this->Request('deleteStickerFromSet', ['sticker' => $sticker]);
    }

    public function DeleteMessage($chatId, $messageId)
    {
        return $this->Request('deleteMessage', ['chat_id' => $chatId, 'message_id' => $messageId]);
    }

    public function Text()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->data;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->text;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->text;

        return @$this->Data->message->text;
    }

    public function Caption()
    {
        return @$this->Data->message->caption;
    }

    public function ChatID()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->message->chat->id;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->chat->id;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->chat->id;

        return $this->Data->message->chat->id;
    }

    public function ChatUsername()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->message->chat->username;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->chat->username;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->chat->username;

        return $this->Data->message->chat->username;
    }

    public function ChatName()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->message->chat->name;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->chat->name;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->chat->name;

        return $this->Data->message->chat->name;
    }

    public function MessageID()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->message->message_id;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->message_id;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->message_id;

        return $this->Data->message->message_id;
    }

    public function ReplyToMessageID()
    {
        return $this->Data->message->reply_to_message->message_id;
    }

    public function ReplyToMessageFromUserID()
    {
        return $this->Data->message->reply_to_message->forward_from->id;
    }

    public function Inline_Query()
    {
        return $this->Data->inline_query;
    }

    public function Callback_Query()
    {
        return $this->Data->callback_query;
    }

    public function Callback_ID()
    {
        return $this->Data->callback_query->id;
    }

    public function Callback_Data()
    {
        return $this->Data->callback_query->data;
    }

    public function Callback_Message()
    {
        return $this->Data->callback_query->message;
    }

    public function Callback_ChatID()
    {
        return $this->Data->callback_query->message->chat->id;
    }

    public function Date()
    {
        return $this->Data->message->date;
    }

    public function FirstName()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->from->first_name;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->from->first_name;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->from->first_name;

        return @$this->Data->message->from->first_name;
    }

    public function LastName()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->from->last_name;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->from->last_name;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->from->last_name;

        return @$this->Data->message->from->last_name;
    }

    public function Username()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return @$this->Data->callback_query->from->username;

        if ($type == self::CHANNEL_POST)
            return @$this->Data->channel_post->from->username;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->from->username;

        return @$this->Data->message->from->username;
    }

    public function Location()
    {
        return $this->Data->message->location;
    }

    public function UpdateID()
    {
        return $this->Data->update_id;
    }

    public function UserID()
    {
        $type = $this->UpdateType();

        if ($type == self::CALLBACK_QUERY)
            return $this->Data->callback_query->from->id;

        if ($type == self::CHANNEL_POST)
            return $this->Data->channel_post->from->id;

        if ($type == self::EDITED_MESSAGE)
            return @$this->Data->edited_message->from->id;

        return $this->Data->message->from->id;
    }

    public function FromID()
    {
        return $this->Data->message->forward_from->id;
    }

    public function FromChatID()
    {
        return $this->Data->message->forward_from_chat->id;
    }

    public function Entities()
    {
        return $this->Data->message->entities;
    }

    public function StartParameter()
    {
        $message = $this->Data->message->text;

        if (!empty($message) && StartsWith($message, '/start '))
            return substr($message, strlen('/start'), strlen($message));

        return '';
    }

    public function IsMessageFromGroup()
    {
        return $this->Data->message->chat->type != 'private';
    }

    public function GroupTitle()
    {
        if ($this->IsMessageFromGroup())
            return $this->Data->message->chat->title;

        return '';
    }

    public function FileName()
    {
        return $this->Data->message->document->file_name;
    }

    public function FileID()
    {
        return $this->Data->message->document->file_id;
    }

    public function FileSize()
    {
        return $this->Data->message->document->file_size;
    }

    public function BuildKeyboard(array $keyboard, $oneTime = false, $resize = false, $selective = true)
    {
        return json_encode(['keyboard' => $keyboard, 'one_time_keyboard' => $oneTime, 'resize_keyboard' => $resize, 'selective' => $selective,]);
    }

    public function BuildInlineKeyboard(array $parameters)
    {
        return json_encode(['inline_keyboard' => $parameters]);
    }

    public function BuildInlineKeyboardButton($text, $url = '', $callbackData = '', $switchInlineQuery = null, $switchInlineQueryCurrentChat = null, $callbackGame = '', $pay = '')
    {
        $replyMarkup = ['text' => $text];

        if ($url != '')
        {
            $replyMarkup['url'] = $url;
        }
        elseif ($callbackData != '')
        {
            $replyMarkup['callback_data'] = $callbackData;
        }
        elseif (!is_null($switchInlineQuery))
        {
            $replyMarkup['switch_inline_query'] = $switchInlineQuery;
        }
        elseif (!is_null($switchInlineQueryCurrentChat))
        {
            $replyMarkup['switch_inline_query_current_chat'] = $switchInlineQueryCurrentChat;
        }
        elseif ($callbackGame != '')
        {
            $replyMarkup['callback_game'] = $callbackGame;
        }
        elseif ($pay != '')
        {
            $replyMarkup['pay'] = $pay;
        }

        return $replyMarkup;
    }

    public function BuildKeyboardButton($text, $requestContact = false, $requestLocation = false)
    {
        return ['text' => $text, 'request_contact' => $requestContact, 'request_location' => $requestLocation,];
    }

    public function BuildKeyBoardHide($selective = true)
    {
        return json_encode(['remove_keyboard' => true, 'selective' => $selective,]);
    }

    public function BuildForceReply($selective = true)
    {
        return json_encode(['force_reply' => true, 'selective' => $selective,]);
    }

    public function UpdateType()
    {
        $update = $this->Data;

        if (isset($update->callback_query))
            return self::CALLBACK_QUERY;

        if (isset($update->edited_message))
            return self::EDITED_MESSAGE;

        if (isset($update->message->reply_to_message))
            return self::REPLY;

        if (isset($update->message->text))
            return self::MESSAGE;

        if (isset($update->message->photo))
            return self::PHOTO;

        if (isset($update->message->video))
            return self::VIDEO;

        if (isset($update->message->audio))
            return self::AUDIO;

        if (isset($update->message->voice))
            return self::VOICE;

        if (isset($update->message->contact))
            return self::CONTACT;

        if (isset($update->message->document))
            return self::DOCUMENT;

        if (isset($update->message->location))
            return self::LOCATION;

        if (isset($update->channel_post))
            return self::CHANNEL_POST;

        return 'Unknown';
    }
}
