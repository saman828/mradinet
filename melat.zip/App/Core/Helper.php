<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

function ErrorHandler($errno, $errstr, $errfile, $errline)
{
    if (DEBUG)
        echo "Line $errline IN $errfile -- " . " -- $errstr</br>";

    Tracer("App.log", "Line $errline IN $errfile -- " . " -- $errstr");
}

function Tracer($FileName, $Message)
{
    file_put_contents(CONFIG_TRACE_DIRECTORY . $FileName, (date("[ Y-m-d H:i:s ] ", microtime(true)) . $Message . "\n"), FILE_APPEND);
}

function JSON($Message, $ApiMessage = '')
{
    header_remove();
    header('Content-Type: application/json');

    exit(json_encode($Message));
}

function Contains($string, $text)
{
    return strpos($string, $text) !== false;
}

function StartsWith($string, $text)
{
    return (substr($string, 0, strlen($text)) === $text);
}

function EndsWith($string, $text)
{
    $length = strlen($text);

    return $length === 0 || (substr($string, -$length) === $text);
}

function GenerateRandomHexString($Bytes = 8)
{
    return strtoupper(bin2hex(openssl_random_pseudo_bytes($Bytes)));
}

function GenerateRandomString($Length)
{
    $Characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    $RandomString = '';

    for ($i = 0; $i < $Length; $i++)
        $RandomString .= $Characters[rand(0, strlen($Characters) - 1)];

    return $RandomString;
}

function GenerateRandomNumber($Length)
{
    $Characters = '0123456789';

    $RandomString = '';

    for ($i = 0; $i < $Length; $i++)
        $RandomString .= $Characters[rand(0, strlen($Characters) - 1)];

    return $RandomString;
}

function ValidateData()
{
    if (empty($_SERVER["CONTENT_TYPE"]) || strpos($_SERVER["CONTENT_TYPE"], 'application/json') === false)
        JSON(['status' => 'BLOCKER_ERROR']);

    $Data = json_decode(file_get_contents("php://input"));

    if (json_last_error() != JSON_ERROR_NONE)
    {
        Tracer("Api.log", "JSON Error:" . json_last_error_msg());
        JSON(['status' => 'BLOCKER_ERROR']);
    }
    else if (get_object_vars($Data))
    {
        return $Data;
    }

    JSON(['status' => 'BLOCKER_ERROR']);
}
