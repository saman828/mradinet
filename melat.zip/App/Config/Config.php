<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

include_once(ROOT . 'App/Config/Core.php');
include_once(ROOT . 'App/Config/DataBase.php');
include_once(ROOT . 'App/Config/Telegram.php');
include_once(ROOT . 'App/Config/ErrorHandling.php');
