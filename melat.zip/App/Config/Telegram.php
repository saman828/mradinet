<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

define('BOT_TOKEN', '591232246:AAERXx38M4HPj_08PvPqKiMWyQ9_6UJBCP0');
define('BOT_OWNERS',
[
    -379245489
]);
