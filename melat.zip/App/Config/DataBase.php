<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

define('DB_HOST', '127.0.0.1', true);
define('DB_PORT', '3306', true);
define('DB_USERNAME', 'root', true);
define('DB_PASSWORD', '', true);
define('DB_NAME', 'evil', true);
