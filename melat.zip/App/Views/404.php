<html>
<head>
    <META HTTP-EQUIV="PRAGMA" CONTENT="NO-CACHE">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>دروازه پرداخت اينترنتي به پرداخت ملت</title>
    <link href="<?= DOMAIN_ROOT ?>/css/Style.yui.css" rel="stylesheet" type="text/css">
    <link rel="shortcut icon" href="<?= DOMAIN_ROOT ?>/images/favicon.ico" type="image/x-icon"/>
      <meta http-equiv="X-Frame-Options" content="deny">
    <script>if (top != self) top.location = location</script>
</head>
<body class="bodyLast">
<form method="post" name="form1">
    <table width="100%">
        <tr>
            <td align="center">
                <table class="NotifyTable">
                    <tr align="center">
                        <td class="InputInfoMainTD">
                            به دروازه پرداخت اينترنتي به پرداخت ملت خوش آمديد
                        </td>
                    </tr>
                    <tr align="center">
                        <td class="InputInfoHintTD">

                            
                            خطای404 رخ داد
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</form>
</body>
</html>