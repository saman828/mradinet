<?php

if (!defined('ROOT'))
{
	include_once('../Views/404.php');
	exit();
}

include_once(ROOT . "App/Core/Helper.php");
include_once(ROOT . "App/Config/Config.php");
include_once(ROOT . "App/Core/Application.php");
include_once(ROOT . "App/Core/Router.php");
include_once(ROOT . 'App/Core/Telegram.php');
include_once(ROOT . "App/Core/Website.php");
